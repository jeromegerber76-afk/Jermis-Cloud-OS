
import express, { Application, Request, Response, NextFunction } from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { config } from './config/config';
import { logger } from './utils/logger';
import { database } from './utils/database';

// Routes importieren
import authRoutes from './routes/auth';
import userRoutes from './routes/users';

class App {
  public app: Application;

  constructor() {
    this.app = express();
    this.initializeMiddlewares();
    this.initializeRoutes();
    this.initializeErrorHandling();
  }

  private initializeMiddlewares(): void {
    // Sicherheits-Middleware
    this.app.use(helmet({
      crossOriginResourcePolicy: { policy: "cross-origin" },
      contentSecurityPolicy: {
        directives: {
          defaultSrc: ["'self'"],
          styleSrc: ["'self'", "'unsafe-inline'"],
          scriptSrc: ["'self'"],
          imgSrc: ["'self'", "data:", "https:"],
        },
      },
    }));

    // CORS Konfiguration
    this.app.use(cors({
  origin: config.nodeEnv === 'production' 
    ? ['https://your-domain.com', 'https://app.your-domain.com'] 
    : ['http://localhost:3000', 'http://localhost:3001', 'http://localhost:5173'],  // ← PORT 5173 HINZUFÜGEN!
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With']
}));

    // Body Parser
    this.app.use(express.json({ limit: '10mb' }));
    this.app.use(express.urlencoded({ extended: true, limit: '10mb' }));

    // Rate Limiting
    const generalLimiter = rateLimit({
      windowMs: config.rateLimit.windowMs,
      max: config.rateLimit.max,
      message: {
        success: false,
        message: 'Too many requests, please try again later'
      },
      standardHeaders: true,
      legacyHeaders: false,
    });

    this.app.use(generalLimiter);

    // Request Logging
    this.app.use((req: Request, res: Response, next: NextFunction) => {
      const start = Date.now();
      
      res.on('finish', () => {
        const duration = Date.now() - start;
        logger.info('HTTP Request', {
          method: req.method,
          url: req.url,
          statusCode: res.statusCode,
          duration: `${duration}ms`,
          ip: req.ip,
          userAgent: req.get('User-Agent')
        });
      });
      
      next();
    });

    // Trust proxy (wichtig für Rate Limiting und IP-Erkennung)
    this.app.set('trust proxy', 1);
  }

  private initializeRoutes(): void {
    // Health Check
    this.app.get('/health', async (req: Request, res: Response) => {
      try {
        const dbHealth = await database.healthCheck();
        
        res.status(dbHealth ? 200 : 503).json({
          success: dbHealth,
          message: dbHealth ? 'Service healthy' : 'Service unhealthy',
          timestamp: new Date().toISOString(),
          uptime: process.uptime(),
          database: dbHealth ? 'connected' : 'disconnected'
        });
      } catch (error) {
        res.status(503).json({
          success: false,
          message: 'Health check failed',
          timestamp: new Date().toISOString()
        });
      }
    });

    // API Info
    this.app.get('/api', (req: Request, res: Response) => {
      res.json({
        success: true,
        message: 'CloudOS.Jermis API',
        version: '1.0.0',
        endpoints: {
          auth: '/api/auth',
          users: '/api/users',
          health: '/health'
        },
        documentation: 'https://docs.your-domain.com/api'
      });
    });

    // API Routes
    this.app.use('/api/auth', authRoutes);
    this.app.use('/api/users', userRoutes);

    // 404 Handler
    this.app.use('*', (req: Request, res: Response) => {
      res.status(404).json({
        success: false,
        message: 'Endpoint not found',
        path: req.originalUrl
      });
    });
  }

  private initializeErrorHandling(): void {
    // Global Error Handler
    this.app.use((error: Error, req: Request, res: Response, next: NextFunction) => {
      logger.error('Unhandled error', {
        error: error.message,
        stack: error.stack,
        url: req.url,
        method: req.method,
        ip: req.ip
      });

      // Verhindere Informationsleckage in Production
      const isDevelopment = config.nodeEnv !== 'production';
      
      res.status(500).json({
        success: false,
        message: 'Internal server error',
        ...(isDevelopment && {
          error: error.message,
          stack: error.stack
        })
      });
    });

    // Unhandled Promise Rejections
    process.on('unhandledRejection', (reason: any) => {
      logger.error('Unhandled Promise Rejection', { reason });
      process.exit(1);
    });

    // Uncaught Exceptions
    process.on('uncaughtException', (error: Error) => {
      logger.error('Uncaught Exception', { error: error.message, stack: error.stack });
      process.exit(1);
    });

    // Graceful Shutdown
    const gracefulShutdown = async (signal: string) => {
      logger.info(`Received ${signal}. Starting graceful shutdown...`);
      
      try {
        await database.close();
        logger.info('Database connection closed');
        process.exit(0);
      } catch (error) {
        logger.error('Error during graceful shutdown', error);
        process.exit(1);
      }
    };

    process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
    process.on('SIGINT', () => gracefulShutdown('SIGINT'));
  }

  public async start(): Promise<void> {
    try {
      // Teste Datenbankverbindung
      const dbHealthy = await database.healthCheck();
      if (!dbHealthy) {
        throw new Error('Database connection failed');
      }

      // Starte Server
      this.app.listen(config.port, () => {
        logger.info('Server started successfully', {
          port: config.port,
          env: config.nodeEnv,
          pid: process.pid
        });
      });

    } catch (error) {
      logger.error('Failed to start server', error);
      process.exit(1);
    }
  }
}

export default App;

// Server starten (main entry point)
if (require.main === module) {
  const app = new App();
  app.start();
}