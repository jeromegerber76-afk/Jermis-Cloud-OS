
import { Request, Response } from 'express';
import { AuthService } from '../services/authService';
import { validateLoginRequest, validateRegisterRequest } from '../utils/validation';
import { logger } from '../utils/logger';

export class AuthController {
  private authService: AuthService;

  constructor() {
    this.authService = new AuthService();
  }

  // POST /api/auth/register
  register = async (req: Request, res: Response): Promise<void> => {
    try {
      // Validiere Input
      const { error, value } = validateRegisterRequest(req.body);
      if (error) {
        res.status(400).json({
          success: false,
          message: 'Validation error',
          errors: error.details.map(d => d.message)
        });
        return;
      }

      // Registriere Benutzer
      const result = await this.authService.register(value);
      
      if (!result.success) {
        res.status(400).json(result);
        return;
      }

      // Erfolgreiche Registrierung
      res.status(201).json({
        success: true,
        message: result.message,
        data: {
          user: result.user,
          token: result.token
        }
      });

    } catch (error) {
      logger.error('Registration controller error', { error, body: req.body });
      res.status(500).json({
        success: false,
        message: 'Registration failed'
      });
    }
  };

  // POST /api/auth/login
  login = async (req: Request, res: Response): Promise<void> => {
    try {
      // Validiere Input
      const { error, value } = validateLoginRequest(req.body);
      if (error) {
        res.status(400).json({
          success: false,
          message: 'Validation error',
          errors: error.details.map(d => d.message)
        });
        return;
      }

      // Client Info für Audit Trail
      const ipAddress = req.ip || req.connection.remoteAddress;
      const userAgent = req.get('User-Agent');

      // Login versuchen
      const result = await this.authService.login(value, ipAddress, userAgent);
      
      if (!result.success) {
        res.status(401).json(result);
        return;
      }

      // Erfolgreicher Login
      res.status(200).json({
        success: true,
        message: result.message,
        data: {
          user: result.user,
          token: result.token
        }
      });

    } catch (error) {
      logger.error('Login controller error', { error });
      res.status(500).json({
        success: false,
        message: 'Login failed'
      });
    }
  };

  // POST /api/auth/refresh
  refreshToken = async (req: Request, res: Response): Promise<void> => {
    try {
      const { refreshToken } = req.body;

      if (!refreshToken) {
        res.status(400).json({
          success: false,
          message: 'Refresh token required'
        });
        return;
      }

      const result = await this.authService.refreshToken(refreshToken);
      
      if (!result.success) {
        res.status(401).json(result);
        return;
      }

      res.status(200).json({
        success: true,
        message: result.message,
        data: {
          user: result.user,
          token: result.token
        }
      });

    } catch (error) {
      logger.error('Token refresh controller error', { error });
      res.status(500).json({
        success: false,
        message: 'Token refresh failed'
      });
    }
  };

  // POST /api/auth/logout
  logout = async (req: Request, res: Response): Promise<void> => {
    try {
      const { refreshToken } = req.body;

      if (!refreshToken) {
        res.status(400).json({
          success: false,
          message: 'Refresh token required'
        });
        return;
      }

      const result = await this.authService.logout(refreshToken);
      
      res.status(200).json(result);

    } catch (error) {
      logger.error('Logout controller error', { error });
      res.status(500).json({
        success: false,
        message: 'Logout failed'
      });
    }
  };


  logoutAll = async (req: Request, res: Response): Promise<void> => {
  try {
    if (!req.user || !req.user.id) {  // ← Prüfe auch req.user.id
      res.status(401).json({
        success: false,
        message: 'Authentication required'
      });
      return;
    }

    const result = await this.authService.logoutAllDevices(req.user.id);  // ← Jetzt ist req.user.id garantiert number
    
    res.status(200).json(result);
  } catch (error) {
    logger.error('Logout all controller error', { error });
    res.status(500).json({
      success: false,
      message: 'Logout all failed'
    });
  }
};

  // GET /api/auth/me
  getCurrentUser = async (req: Request, res: Response): Promise<void> => {
    try {
      if (!req.user) {
        res.status(401).json({
          success: false,
          message: 'Authentication required'
        });
        return;
      }

      res.status(200).json({
        success: true,
        data: {
          user: req.user
        }
      });

    } catch (error) {
      logger.error('Get current user error', { error });
      res.status(500).json({
        success: false,
        message: 'Failed to get user info'
      });
    }
  };
}