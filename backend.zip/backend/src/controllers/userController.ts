import { Request, Response } from 'express';
import { UserService } from '../services/userService';
import { validateUpdateUserRequest } from '../utils/validation';
import { logger } from '../utils/logger';

export class UserController {
  private userService: UserService;

  constructor() {
    this.userService = new UserService();
  }

  // GET /api/users (nur für Admins)
  getAllUsers = async (req: Request, res: Response): Promise<void> => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = Math.min(parseInt(req.query.limit as string) || 50, 100); // Max 100

      const result = await this.userService.getAllUsers(page, limit);

      res.status(200).json({
        success: true,
        data: result
      });

    } catch (error) {
      logger.error('Get all users error', { error });
      res.status(500).json({
        success: false,
        message: 'Failed to get users'
      });
    }
  };

  // GET /api/users/:userId
  getUserById = async (req: Request, res: Response): Promise<void> => {
    try {
      const userId = parseInt(req.params.userId);
      
      if (isNaN(userId)) {
        res.status(400).json({
          success: false,
          message: 'Invalid user ID'
        });
        return;
      }

      const user = await this.userService.findById(userId);

      if (!user) {
        res.status(404).json({
          success: false,
          message: 'User not found'
        });
        return;
      }

      res.status(200).json({
        success: true,
        data: { user }
      });

    } catch (error) {
      logger.error('Get user by ID error', { error, userId: req.params.userId });
      res.status(500).json({
        success: false,
        message: 'Failed to get user'
      });
    }
  };

  // PUT /api/users/:userId/role (nur für Admins)
  updateUserRole = async (req: Request, res: Response): Promise<void> => {
    try {
      const userId = parseInt(req.params.userId);
      const { role } = req.body;

      if (isNaN(userId)) {
        res.status(400).json({
          success: false,
          message: 'Invalid user ID'
        });
        return;
      }

      // Validiere Rolle
      const validRoles = ['admin', 'support', 'buchhaltung', 'lager', 'mitarbeiter', 'externe', 'gast'];
      if (!validRoles.includes(role)) {
        res.status(400).json({
          success: false,
          message: 'Invalid role',
          validRoles
        });
        return;
      }

      // Prüfe ob User existiert
      const user = await this.userService.findById(userId);
      if (!user) {
        res.status(404).json({
          success: false,
          message: 'User not found'
        });
        return;
      }

      // Admin kann sich nicht selbst degradieren
      if (req.user?.id === userId && req.user.role === 'admin' && role !== 'admin') {
        res.status(400).json({
          success: false,
          message: 'Cannot change your own admin role'
        });
        return;
      }

      await this.userService.updateUserRole(userId, role);

      res.status(200).json({
        success: true,
        message: 'User role updated successfully'
      });

    } catch (error) {
      logger.error('Update user role error', { error, userId: req.params.userId });
      res.status(500).json({
        success: false,
        message: 'Failed to update user role'
      });
    }
  };

  // DELETE /api/users/:userId (nur für Admins)
  deactivateUser = async (req: Request, res: Response): Promise<void> => {
    try {
      const userId = parseInt(req.params.userId);

      if (isNaN(userId)) {
        res.status(400).json({
          success: false,
          message: 'Invalid user ID'
        });
        return;
      }

      // Admin kann sich nicht selbst deaktivieren
      if (req.user?.id === userId) {
        res.status(400).json({
          success: false,
          message: 'Cannot deactivate your own account'
        });
        return;
      }

      const user = await this.userService.findById(userId);
      if (!user) {
        res.status(404).json({
          success: false,
          message: 'User not found'
        });
        return;
      }

      await this.userService.deactivateUser(userId);

      res.status(200).json({
        success: true,
        message: 'User deactivated successfully'
      });

    } catch (error) {
      logger.error('Deactivate user error', { error, userId: req.params.userId });
      res.status(500).json({
        success: false,
        message: 'Failed to deactivate user'
      });
    }
  };
}