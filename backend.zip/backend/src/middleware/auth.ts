
import { Request, Response, NextFunction } from 'express';
import { AuthService } from '../services/authService';
import { UserService } from '../services/userService';
import { UserRole } from '../models/User';
import { logger } from '../utils/logger';
import { UserWithoutPassword } from '../models/User';

declare global {
  namespace Express {
    interface Request {
      user?: UserWithoutPassword;  // ← Verwende den existierenden Typ
    }
  }
}

export class AuthMiddleware {
  private authService: AuthService;
  private userService: UserService;

  constructor() {
    this.authService = new AuthService();
    this.userService = new UserService();
  }

  // Token aus Header extrahieren
  private extractToken(req: Request): string | null {
    const authHeader = req.headers.authorization;
    
    if (!authHeader) {
      return null;
    }

    if (authHeader.startsWith('Bearer ')) {
      return authHeader.substring(7);
    }

    return null;
  }

  // Benutzer authentifizieren
  authenticate = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const token = this.extractToken(req);
      
      if (!token) {
        res.status(401).json({
          success: false,
          message: 'No token provided'
        });
        return;
      }

      // Token verifizieren
      const tokenResult = await this.authService.verifyToken(token);
      
      if (!tokenResult.valid) {
        res.status(401).json({
          success: false,
          message: tokenResult.error || 'Invalid token'
        });
        return;
      }

      // Benutzer laden
      const user = await this.userService.findById(tokenResult.userId!);
      
      if (!user) {
        res.status(401).json({
          success: false,
          message: 'User not found'
        });
        return;
      }

      // Benutzer zur Request hinzufügen
      req.user = user;
      next();
      
    } catch (error) {
      logger.error('Authentication middleware error', { error, path: req.path });
      res.status(500).json({
        success: false,
        message: 'Authentication failed'
      });
    }
  };

  // Optionale Authentifizierung (für öffentliche Endpoints die erweiterte Funktionen für eingeloggte User haben)
  optionalAuthenticate = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const token = this.extractToken(req);
      
      if (!token) {
        next();
        return;
      }

      const tokenResult = await this.authService.verifyToken(token);
      
      if (tokenResult.valid && tokenResult.userId) {
        const user = await this.userService.findById(tokenResult.userId);
        if (user) {
          req.user = user;
        }
      }

      next();
    } catch (error) {
      logger.error('Optional authentication error', { error, path: req.path });
      next(); // Weiter auch bei Fehlern
    }
  };
}