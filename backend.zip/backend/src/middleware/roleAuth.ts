
import { Request, Response, NextFunction } from 'express';
import { UserRole } from '../models/User';

// Rollen-Hierarchie definieren
const ROLE_HIERARCHY: Record<UserRole, number> = {
  gast: 0,
  externe: 1,
  mitarbeiter: 2,
  lager: 3,
  buchhaltung: 4,
  support: 5,
  admin: 6
};

// Berechtigungen pro Modul definieren
const MODULE_PERMISSIONS: Record<string, Record<UserRole, string[]>> = {
  users: {
    gast: [],
    externe: ['read_own'],
    mitarbeiter: ['read_own', 'update_own'],
    lager: ['read_own', 'update_own'],
    buchhaltung: ['read_own', 'update_own'],
    support: ['read_all', 'update_all'],
    admin: ['create', 'read_all', 'update_all', 'delete']
  },
  dashboard: {
    gast: [],
    externe: ['read_basic'],
    mitarbeiter: ['read_basic', 'read_own_stats'],
    lager: ['read_basic', 'read_own_stats', 'read_inventory'],
    buchhaltung: ['read_basic', 'read_own_stats', 'read_finance'],
    support: ['read_all'],
    admin: ['read_all', 'manage_all']
  },
  inventory: {
    gast: [],
    externe: [],
    mitarbeiter: ['read'],
    lager: ['read', 'create', 'update'],
    buchhaltung: ['read'],
    support: ['read', 'create', 'update'],
    admin: ['read', 'create', 'update', 'delete']
  }
};

export class RoleAuthMiddleware {
  
  // Mindest-Rolle prüfen
  static requireMinRole(minRole: UserRole) {
    return (req: Request, res: Response, next: NextFunction): void => {
      if (!req.user) {
        res.status(401).json({
          success: false,
          message: 'Authentication required'
        });
        return;
      }

      const userRoleLevel = ROLE_HIERARCHY[req.user.role];
      const minRoleLevel = ROLE_HIERARCHY[minRole];

      if (userRoleLevel < minRoleLevel) {
        res.status(403).json({
          success: false,
          message: 'Insufficient permissions',
          required: minRole,
          current: req.user.role
        });
        return;
      }

      next();
    };
  }

  // Spezifische Rollen prüfen
  static requireRoles(allowedRoles: UserRole[]) {
    return (req: Request, res: Response, next: NextFunction): void => {
      if (!req.user) {
        res.status(401).json({
          success: false,
          message: 'Authentication required'
        });
        return;
      }

      if (!allowedRoles.includes(req.user.role)) {
        res.status(403).json({
          success: false,
          message: 'Insufficient permissions',
          allowed: allowedRoles,
          current: req.user.role
        });
        return;
      }

      next();
    };
  }

  // Modul-basierte Berechtigung prüfen
  static requireModulePermission(module: string, permission: string) {
    return (req: Request, res: Response, next: NextFunction): void => {
      if (!req.user) {
        res.status(401).json({
          success: false,
          message: 'Authentication required'
        });
        return;
      }

      const modulePerms = MODULE_PERMISSIONS[module];
      if (!modulePerms) {
        res.status(500).json({
          success: false,
          message: 'Module not configured'
        });
        return;
      }

      const userPermissions = modulePerms[req.user.role] || [];
      
      if (!userPermissions.includes(permission)) {
        res.status(403).json({
          success: false,
          message: 'Insufficient permissions for this action',
          module,
          permission,
          role: req.user.role
        });
        return;
      }

      next();
    };
  }

  // Admin-Zugriff prüfen
  static requireAdmin = RoleAuthMiddleware.requireRoles(['admin']);

  // Support oder Admin prüfen
  static requireSupport = RoleAuthMiddleware.requireMinRole('support');

  // Eigene Ressource oder Admin prüfen (für Profile-Updates etc.)
  static requireOwnershipOrAdmin(userIdParam: string = 'userId') {
    return (req: Request, res: Response, next: NextFunction): void => {
      if (!req.user) {
        res.status(401).json({
          success: false,
          message: 'Authentication required'
        });
        return;
      }

      // Admin hat immer Zugriff
      if (req.user.role === 'admin') {
        next();
        return;
      }

      // Prüfe ob User auf eigene Ressource zugreift
      const targetUserId = parseInt(req.params[userIdParam]);
      if (req.user.id === targetUserId) {
        next();
        return;
      }

      res.status(403).json({
        success: false,
        message: 'Can only access your own resources'
      });
    };
  }
}