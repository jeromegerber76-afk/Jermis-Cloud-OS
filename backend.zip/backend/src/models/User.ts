
export interface User {
  id?: number;
  email: string;
  password_hash: string;
  first_name: string;
  last_name: string;
  role: UserRole;
  is_active: boolean;
  last_login?: Date;
  created_at?: Date;
  updated_at?: Date;
}

export interface UserSession {
  id?: number;
  user_id: number;
  token_hash: string;
  expires_at: Date;
  ip_address?: string;
  user_agent?: string;
  created_at?: Date;
}

export interface AuditLog {
  id?: number;
  user_id?: number;
  action: string;
  table_name?: string;
  record_id?: number;
  old_values?: any;
  new_values?: any;
  ip_address?: string;
  created_at?: Date;
}

export type UserRole = 'admin' | 'support' | 'buchhaltung' | 'lager' | 'mitarbeiter' | 'externe' | 'gast';

export interface UserWithoutPassword extends Omit<User, 'password_hash'> {}

export interface LoginRequest {
  email: string;
  password: string;
}

export interface RegisterRequest {
  email: string;
  password: string;
  first_name: string;
  last_name: string;
  role?: UserRole;
}

export interface AuthResponse {
  success: boolean;
  message: string;
  user?: UserWithoutPassword;
  token?: string;
  refreshToken?: string;
}