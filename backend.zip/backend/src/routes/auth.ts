
import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import { AuthController } from '../controllers/authController';
import { AuthMiddleware } from '../middleware/auth';
import { config } from '../config/config';

const router = Router();
const authController = new AuthController();
const authMiddleware = new AuthMiddleware();

// Rate Limiting für Auth-Endpoints
const authLimiter = rateLimit({
  windowMs: config.rateLimit.windowMs,
  max: config.rateLimit.maxLogin,
  message: {
    success: false,
    message: 'Too many authentication attempts, please try again later'
  },
  standardHeaders: true,
  legacyHeaders: false,
});

// Öffentliche Routes (mit Rate Limiting)
router.post('/register', authLimiter, authController.register);
router.post('/login', authLimiter, authController.login);
router.post('/refresh', authLimiter, authController.refreshToken);

// Geschützte Routes (erfordern Authentication)
router.post('/logout', authMiddleware.authenticate, authController.logout);
router.post('/logout-all', authMiddleware.authenticate, authController.logoutAll);
router.get('/me', authMiddleware.authenticate, authController.getCurrentUser);

export default router;