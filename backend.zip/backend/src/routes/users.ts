import { Router } from 'express';
import { UserController } from '../controllers/userController';
import { AuthMiddleware } from '../middleware/auth';
import { RoleAuthMiddleware } from '../middleware/roleAuth';

const router = Router();
const userController = new UserController();
const authMiddleware = new AuthMiddleware();

// Alle Routes erfordern Authentication
router.use(authMiddleware.authenticate);

// GET /api/users - Alle Benutzer abrufen (nur Admin)
router.get('/', 
  RoleAuthMiddleware.requireAdmin,
  userController.getAllUsers
);

// GET /api/users/:userId - Spezifischen Benutzer abrufen (Owner oder Admin)
router.get('/:userId',
  RoleAuthMiddleware.requireOwnershipOrAdmin(),
  userController.getUserById
);

// PUT /api/users/:userId/role - Benutzer-Rolle ändern (nur Admin)
router.put('/:userId/role',
  RoleAuthMiddleware.requireAdmin,
  userController.updateUserRole
);

// DELETE /api/users/:userId - Benutzer deaktivieren (nur Admin)
router.delete('/:userId',
  RoleAuthMiddleware.requireAdmin,
  userController.deactivateUser
);

export default router;