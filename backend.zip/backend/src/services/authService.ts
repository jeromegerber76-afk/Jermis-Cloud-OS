import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import { database } from '../utils/database';
import { UserService } from './userService';
import { User, UserWithoutPassword, AuthResponse, LoginRequest, RegisterRequest, UserSession } from '../models/User';
import { config } from '../config/config';
import { logger } from '../utils/logger';

export class AuthService {
  private userService: UserService;

  constructor() {
    this.userService = new UserService();
  }

  // Benutzer registrieren
  async register(userData: RegisterRequest): Promise<AuthResponse> {
    try {
      // Prüfe ob Email bereits existiert
      const existingUser = await this.userService.findByEmail(userData.email);
      if (existingUser) {
        return {
          success: false,
          message: 'Email already registered'
        };
      }

      // Erstelle Benutzer
      const newUser = await this.userService.createUser(userData);
      
      // Generiere Token
      const tokens = await this.generateTokens(newUser.id!);

      return {
        success: true,
        message: 'User registered successfully',
        user: newUser,
        token: tokens.accessToken,
        refreshToken: tokens.refreshToken
      };
    } catch (error: any) {
      logger.error('Registration error', { error, email: userData.email });
      return {
        success: false,
        message: error.message || 'Registration failed'
      };
    }
  }

  // Benutzer anmelden
  async login(credentials: LoginRequest, ipAddress?: string, userAgent?: string): Promise<AuthResponse> {
    try {
      // Finde Benutzer
      const user = await this.userService.findByEmail(credentials.email);
      if (!user) {
        return {
          success: false,
          message: 'Invalid email or password'
        };
      }

      // Prüfe Passwort
      const isValidPassword = await this.userService.verifyPassword(credentials.password, user.password_hash);
      if (!isValidPassword) {
        logger.warn('Failed login attempt', { email: credentials.email, ipAddress });
        return {
          success: false,
          message: 'Invalid email or password'
        };
      }

      // Aktualisiere letzten Login
      await this.userService.updateLastLogin(user.id!);

      // Generiere Token
      const tokens = await this.generateTokens(user.id!, ipAddress, userAgent);

      // Entferne Passwort aus Response
      const { password_hash, ...userWithoutPassword } = user;

      logger.info('Successful login', { userId: user.id, email: user.email, ipAddress });

      return {
        success: true,
        message: 'Login successful',
        user: userWithoutPassword,
        token: tokens.accessToken,
        refreshToken: tokens.refreshToken
      };
    } catch (error: any) {
      logger.error('Login error', { error, email: credentials.email });
      return {
        success: false,
        message: 'Login failed'
      };
    }
  }

  // Token generieren
  private async generateTokens(userId: number, ipAddress?: string, userAgent?: string): Promise<{
    accessToken: string;
    refreshToken: string;
  }> 
  {
    // Access Token (kurz gültig)
    const payload = { 
  userId, 
  type: 'access',
  iat: Math.floor(Date.now() / 1000)
};

const accessToken = jwt.sign(
  payload, 
  config.jwt.secret, 
  { expiresIn: config.jwt.expiresIn } as jwt.SignOptions
);

    // Refresh Token (länger gültig)
    const refreshToken = crypto.randomBytes(40).toString('hex');
    const refreshTokenHash = crypto.createHash('sha256').update(refreshToken).digest('hex');

    // Speichere Refresh Token in Datenbank
    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000); // 7 Tage
    
    const query = `
      INSERT INTO user_sessions (user_id, token_hash, expires_at, ip_address, user_agent)
      VALUES ($1, $2, $3, $4, $5)
    `;
    
    await database.query(query, [userId, refreshTokenHash, expiresAt, ipAddress, userAgent]);

    return {
      accessToken,
      refreshToken
    };
  }

  // Token verifizieren
  async verifyToken(token: string): Promise<{ valid: boolean; userId?: number; error?: string }> {
    try {
      const decoded = jwt.verify(token, config.jwt.secret) as any;
      
      if (decoded.type !== 'access') {
        return { valid: false, error: 'Invalid token type' };
      }

      return { valid: true, userId: decoded.userId };
    } catch (error: any) {
      if (error.name === 'TokenExpiredError') {
        return { valid: false, error: 'Token expired' };
      } else if (error.name === 'JsonWebTokenError') {
        return { valid: false, error: 'Invalid token' };
      }
      return { valid: false, error: 'Token verification failed' };
    }
  }

  // Refresh Token
  async refreshToken(refreshToken: string): Promise<AuthResponse> {
    try {
      const tokenHash = crypto.createHash('sha256').update(refreshToken).digest('hex');
      
      const query = `
        SELECT us.*, u.id as user_id, u.email, u.role, u.is_active
        FROM user_sessions us
        JOIN users u ON us.user_id = u.id
        WHERE us.token_hash = $1 AND us.expires_at > NOW() AND u.is_active = true
      `;
      
      const result = await database.query(query, [tokenHash]);
      
      if (result.rows.length === 0) {
        return {
          success: false,
          message: 'Invalid refresh token'
        };
      }

      const session = result.rows[0];
      
      // Lösche altes Session-Token
      await database.query('DELETE FROM user_sessions WHERE id = $1', [session.id]);
      
      // Generiere neue Token
      const tokens = await this.generateTokens(session.user_id, session.ip_address, session.user_agent);
      
      // Hole Benutzerdaten
      const user = await this.userService.findById(session.user_id);

      return {
  success: true,
  message: 'Token refreshed successfully',
  user: user || undefined,    // ← Wandle null zu undefined um
  token: tokens.accessToken,
  refreshToken: tokens.refreshToken
};
    } catch (error) {
      logger.error('Token refresh error', error);
      return {
        success: false,
        message: 'Token refresh failed'
      };
    }
  }

  // Benutzer abmelden (Token invalidieren)
  async logout(refreshToken: string): Promise<{ success: boolean; message: string }> {
    try {
      const tokenHash = crypto.createHash('sha256').update(refreshToken).digest('hex');
      await database.query('DELETE FROM user_sessions WHERE token_hash = $1', [tokenHash]);
      
      return {
        success: true,
        message: 'Logout successful'
      };
    } catch (error) {
      logger.error('Logout error', error);
      return {
        success: false,
        message: 'Logout failed'
      };
    }
  }

  // Alle Sessions eines Users löschen
  async logoutAllDevices(userId: number): Promise<{ success: boolean; message: string }> {
    try {
      await database.query('DELETE FROM user_sessions WHERE user_id = $1', [userId]);
      
      return {
        success: true,
        message: 'Logged out from all devices'
      };
    } catch (error) {
      logger.error('Logout all devices error', error);
      return {
        success: false,
        message: 'Logout from all devices failed'
      };
    }
  }
}