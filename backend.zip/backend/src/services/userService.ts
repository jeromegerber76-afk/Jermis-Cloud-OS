import bcrypt from 'bcryptjs';
import { database } from '../utils/database';
import { User, UserWithoutPassword, UserRole } from '../models/User';
import { config } from '../config/config';
import { logger } from '../utils/logger';

export class UserService {
  
  // Benutzer erstellen
  async createUser(userData: {
    email: string;
    password: string;
    first_name: string;
    last_name: string;
    role?: UserRole;
  }): Promise<UserWithoutPassword> {
    const hashedPassword = await bcrypt.hash(userData.password, config.security.bcryptRounds);
    
    const query = `
      INSERT INTO users (email, password_hash, first_name, last_name, role)
      VALUES ($1, $2, $3, $4, $5)
      RETURNING id, email, first_name, last_name, role, is_active, created_at, updated_at
    `;
    
    const values = [
      userData.email.toLowerCase(),
      hashedPassword,
      userData.first_name,
      userData.last_name,
      userData.role || 'mitarbeiter'
    ];
    
    try {
      const result = await database.query(query, values);
      const user = result.rows[0];
      
      logger.info(`User created: ${user.email}`, { userId: user.id });
      
      return user;
    } catch (error: any) {
      if (error.code === '23505') { // Unique constraint violation
        throw new Error('Email already exists');
      }
      logger.error('Error creating user', { error, email: userData.email });
      throw new Error('Failed to create user');
    }
  }

  // Benutzer per Email finden
  async findByEmail(email: string): Promise<User | null> {
    const query = 'SELECT * FROM users WHERE email = $1 AND is_active = true';
    const result = await database.query(query, [email.toLowerCase()]);
    
    return result.rows[0] || null;
  }

  // Benutzer per ID finden (ohne Passwort)
  async findById(id: number): Promise<UserWithoutPassword | null> {
    const query = `
      SELECT id, email, first_name, last_name, role, is_active, last_login, created_at, updated_at 
      FROM users 
      WHERE id = $1 AND is_active = true
    `;
    const result = await database.query(query, [id]);
    
    return result.rows[0] || null;
  }

  // Passwort verifizieren
  async verifyPassword(password: string, hashedPassword: string): Promise<boolean> {
    return await bcrypt.compare(password, hashedPassword);
  }

  // Letzten Login aktualisieren
  async updateLastLogin(userId: number): Promise<void> {
    const query = 'UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = $1';
    await database.query(query, [userId]);
  }

  // Alle Benutzer abrufen (nur für Admins)
  async getAllUsers(page: number = 1, limit: number = 50): Promise<{
    users: UserWithoutPassword[];
    total: number;
    page: number;
    totalPages: number;
  }> {
    const offset = (page - 1) * limit;
    
    // Zähle Gesamtanzahl
    const countQuery = 'SELECT COUNT(*) FROM users WHERE is_active = true';
    const countResult = await database.query(countQuery);
    const total = parseInt(countResult.rows[0].count);
    
    // Hole Benutzer mit Pagination
    const query = `
      SELECT id, email, first_name, last_name, role, is_active, last_login, created_at, updated_at 
      FROM users 
      WHERE is_active = true 
      ORDER BY created_at DESC 
      LIMIT $1 OFFSET $2
    `;
    
    const result = await database.query(query, [limit, offset]);
    
    return {
      users: result.rows,
      total,
      page,
      totalPages: Math.ceil(total / limit)
    };
  }

  // Benutzer deaktivieren (DSGVO-konform)
  async deactivateUser(userId: number): Promise<void> {
    const query = 'UPDATE users SET is_active = false, updated_at = CURRENT_TIMESTAMP WHERE id = $1';
    await database.query(query, [userId]);
    
    logger.info(`User deactivated`, { userId });
  }

  // Rolle ändern
  async updateUserRole(userId: number, newRole: UserRole): Promise<void> {
    const query = 'UPDATE users SET role = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2';
    await database.query(query, [newRole, userId]);
    
    logger.info(`User role updated`, { userId, newRole });
  }
}