
import winston from 'winston';
import { config } from '../config/config';

// Custom Format für bessere Lesbarkeit
const customFormat = winston.format.combine(
  winston.format.timestamp({
    format: 'YYYY-MM-DD HH:mm:ss'
  }),
  winston.format.errors({ stack: true }),
  winston.format.json(),
  winston.format.prettyPrint()
);

// Console Format für Development
const consoleFormat = winston.format.combine(
  winston.format.colorize(),
  winston.format.simple(),
  winston.format.printf(({ timestamp, level, message, ...meta }) => {
    return `${timestamp} [${level}]: ${message} ${
      Object.keys(meta).length ? JSON.stringify(meta, null, 2) : ''
    }`;
  })
);

// Logger Konfiguration
export const logger = winston.createLogger({
  level: config.nodeEnv === 'production' ? 'info' : 'debug',
  format: customFormat,
  defaultMeta: { service: 'cloudos-jermis-backend' },
  transports: [
    // Fehler-Log
    new winston.transports.File({ 
      filename: 'logs/error.log', 
      level: 'error',
      maxsize: 5242880, // 5MB
      maxFiles: 5
    }),
    
    // Kombinierte Logs
    new winston.transports.File({ 
      filename: 'logs/combined.log',
      maxsize: 5242880, // 5MB
      maxFiles: 5
    }),
    
    // Audit Logs (für DSGVO)
    new winston.transports.File({ 
      filename: 'logs/audit.log',
      level: 'info',
      format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.json()
      ),
      maxsize: 10485760, // 10MB
      maxFiles: 10
    })
  ]
});

// Console Output für Development
if (config.nodeEnv !== 'production') {
  logger.add(new winston.transports.Console({
    format: consoleFormat
  }));
}

// Sichere Log-Funktion (entfernt sensible Daten)
export const logSecure = (level: string, message: string, meta: any = {}) => {
  // Sensible Felder entfernen/maskieren
  const safeMeta = { ...meta };
  
  // Passwörter entfernen
  if (safeMeta.password) delete safeMeta.password;
  if (safeMeta.password_hash) delete safeMeta.password_hash;
  if (safeMeta.token) safeMeta.token = '***masked***';
  
  // Email nur teilweise anzeigen
  if (safeMeta.email) {
    const [local, domain] = safeMeta.email.split('@');
    safeMeta.email = `${local.substring(0, 2)}***@${domain}`;
  }

  logger.log(level, message, safeMeta);
};

// Audit Log speziell für DSGVO
export const auditLog = (action: string, userId?: number, details: any = {}) => {
  logger.info('AUDIT', {
    action,
    userId,
    timestamp: new Date().toISOString(),
    details: details,
    level: 'audit'
  });
};