import Joi from 'joi';

// Login Validierung
export const validateLoginRequest = (data: any) => {
  const schema = Joi.object({
    email: Joi.string()
      .email()
      .required()
      .messages({
        'string.email': 'Please enter a valid email address',
        'any.required': 'Email is required'
      }),
    password: Joi.string()
      .min(6)
      .required()
      .messages({
        'string.min': 'Password must be at least 6 characters long',
        'any.required': 'Password is required'
      })
  });

  return schema.validate(data);
};

// Registrierung Validierung
export const validateRegisterRequest = (data: any) => {
  const schema = Joi.object({
    email: Joi.string()
      .email()
      .required()
      .messages({
        'string.email': 'Please enter a valid email address',
        'any.required': 'Email is required'
      }),
    password: Joi.string()
      .min(8)
      .pattern(new RegExp('^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)'))
      .required()
      .messages({
        'string.min': 'Password must be at least 8 characters long',
        'string.pattern.base': 'Password must contain at least one uppercase letter, one lowercase letter, and one number',
        'any.required': 'Password is required'
      }),
    first_name: Joi.string()
      .min(2)
      .max(50)
      .pattern(/^[a-zA-ZäöüÄÖÜß\s-]+$/)
      .required()
      .messages({
        'string.min': 'First name must be at least 2 characters long',
        'string.max': 'First name cannot exceed 50 characters',
        'string.pattern.base': 'First name can only contain letters, spaces, and hyphens',
        'any.required': 'First name is required'
      }),
    last_name: Joi.string()
      .min(2)
      .max(50)
      .pattern(/^[a-zA-ZäöüÄÖÜß\s-]+$/)
      .required()
      .messages({
        'string.min': 'Last name must be at least 2 characters long',
        'string.max': 'Last name cannot exceed 50 characters',
        'string.pattern.base': 'Last name can only contain letters, spaces, and hyphens',
        'any.required': 'Last name is required'
      }),
    role: Joi.string()
      .valid('admin', 'support', 'buchhaltung', 'lager', 'mitarbeiter', 'externe', 'gast')
      .optional()
      .default('mitarbeiter')
      .messages({
        'any.only': 'Invalid role specified'
      })
  });

  return schema.validate(data);
};

// User Update Validierung
export const validateUpdateUserRequest = (data: any) => {
  const schema = Joi.object({
    first_name: Joi.string()
      .min(2)
      .max(50)
      .pattern(/^[a-zA-ZäöüÄÖÜß\s-]+$/)
      .optional()
      .messages({
        'string.min': 'First name must be at least 2 characters long',
        'string.max': 'First name cannot exceed 50 characters',
        'string.pattern.base': 'First name can only contain letters, spaces, and hyphens'
      }),
    last_name: Joi.string()
      .min(2)
      .max(50)
      .pattern(/^[a-zA-ZäöüÄÖÜß\s-]+$/)
      .optional()
      .messages({
        'string.min': 'Last name must be at least 2 characters long',
        'string.max': 'Last name cannot exceed 50 characters',
        'string.pattern.base': 'Last name can only contain letters, spaces, and hyphens'
      }),
    email: Joi.string()
      .email()
      .optional()
      .messages({
        'string.email': 'Please enter a valid email address'
      })
  }).min(1).messages({
    'object.min': 'At least one field must be provided for update'
  });

  return schema.validate(data);
};

// Passwort-Änderung Validierung
export const validatePasswordChangeRequest = (data: any) => {
  const schema = Joi.object({
    currentPassword: Joi.string()
      .required()
      .messages({
        'any.required': 'Current password is required'
      }),
    newPassword: Joi.string()
      .min(8)
      .pattern(new RegExp('^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)'))
      .required()
      .messages({
        'string.min': 'New password must be at least 8 characters long',
        'string.pattern.base': 'New password must contain at least one uppercase letter, one lowercase letter, and one number',
        'any.required': 'New password is required'
      }),
    confirmPassword: Joi.string()
      .valid(Joi.ref('newPassword'))
      .required()
      .messages({
        'any.only': 'Password confirmation does not match new password',
        'any.required': 'Password confirmation is required'
      })
  });

  return schema.validate(data);
};

// Email Validierung (für Password Reset etc.)
export const validateEmailRequest = (data: any) => {
  const schema = Joi.object({
    email: Joi.string()
      .email()
      .required()
      .messages({
        'string.email': 'Please enter a valid email address',
        'any.required': 'Email is required'
      })
  });

  return schema.validate(data);
};

// Allgemeine Validierung für Query Parameter
export const validatePaginationQuery = (query: any) => {
  const schema = Joi.object({
    page: Joi.number()
      .integer()
      .min(1)
      .optional()
      .default(1),
    limit: Joi.number()
      .integer()
      .min(1)
      .max(100)
      .optional()
      .default(50),
    search: Joi.string()
      .max(100)
      .optional(),
    sortBy: Joi.string()
      .valid('email', 'first_name', 'last_name', 'role', 'created_at', 'last_login')
      .optional()
      .default('created_at'),
    sortOrder: Joi.string()
      .valid('asc', 'desc')
      .optional()
      .default('desc')
  });

  return schema.validate(query);
};
